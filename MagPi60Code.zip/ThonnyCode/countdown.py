n = 10

while n > 0:
	print(n)
	n-=1

print("Blast Off!")